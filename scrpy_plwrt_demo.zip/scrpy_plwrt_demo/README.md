1. `winget install --id=Python.Python.3.13 -e`
2. `configurator.bat`
3. `python3.13 -m venv venv`
4. 